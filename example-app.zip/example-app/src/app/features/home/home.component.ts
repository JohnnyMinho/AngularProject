// src/app/features/home/home.component.ts

import { Component } from '@angular/core'


@Component({
  moduleId: module.id,
  selector: 'ns-home',
  templateUrl: 'home.component.html'
})
export class HomeComponent {}
